package com.scaler.SplitwiseMay2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SplitwiseMay2023Application {

	public static void main(String[] args) {
		SpringApplication.run(SplitwiseMay2023Application.class, args);
	}

}
